const request = require('supertest')
const server = require('./server')

describe('server', () => {
    it('has a GET / endpoint', async () => {
        await request(server)
        .get('/')
        .expect(200)
    })

    it('has a GET / endpoint that returns 200', async () => {
        await request(server)
        .get('/')
        .expect(200)
    })

    it('has a GET / endpoint that returns json', async () => {
        const expectedJSON = { "api": "running" }

        const response = await request(server).get('/')

        expect(response.body).toEqual(expectedJSON)
    })
})
