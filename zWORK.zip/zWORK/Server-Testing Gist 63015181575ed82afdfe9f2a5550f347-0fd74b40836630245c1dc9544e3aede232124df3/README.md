Requirements:
1. Return 200 (OK) and `{ "api": "running" }` when `GET /`
2. Hash a user's password before they are saved to the database

Write tests!
