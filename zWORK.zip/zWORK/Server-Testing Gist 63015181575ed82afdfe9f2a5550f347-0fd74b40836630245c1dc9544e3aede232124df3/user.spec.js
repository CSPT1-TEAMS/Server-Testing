const User = require('./user')
const mongoose = require('mongoose')

describe('user model', () => {
  beforeAll(() => {
    return mongoose.connect('mongodb://localhost/testdb')
  })

  afterAll(() => {
    return mongoose.disconnect()
  })

  afterEach(() => {
    return User.remove()
  })

  it('should save users to the database', async () => {
    const user = { username: 'Russell', password: 'password' }

    await User.create(user)
  })

  it('should hash a user\'s password before they are saved to the database', async () => {
    const user = { username: 'Russell', password: 'password' }

    const newUser = await User.create(user)

    expect(newUser.password).not.toBe(user.password)
  })
})
